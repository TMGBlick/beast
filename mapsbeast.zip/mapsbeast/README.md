# mapsbeast

A Google Maps scraper + AI-enrichment pipeline, built from scratch (not a
clone of anyone's code — this replicates the *category* of tool, designed
independently).

Two phases, run separately:

1. **Scrape** — headless Playwright browser(s) pull listings directly off
   Google Maps search. Fully headless, no rendered window — you can run
   several instances at once and watch all of them in a single dashboard:
   one row per worker (status, count, error tally), plus a dedicated
   "Warnings & Errors" panel below that surfaces only the stuff across all
   workers you actually need to see, since these scrapers fail silently far
   more often than they fail loudly.
2. **Enrich** — for each listing with a website, crawls the site for emails,
   phones, social links, and tech-stack signals (pure extraction, no AI),
   then optionally sends those signals to Claude to synthesize a firmographic
   profile (company size, industry, revenue band — clearly labeled as
   *inference*, not fact, with a confidence rating).

## Setup

```bash
pip install -r requirements.txt
playwright install chromium   # downloads the browser binary — do this once
export ANTHROPIC_API_KEY=sk-ant-...   # only needed for the --ai enrichment step
```

## Usage

```bash
# Single query
python cli.py scrape "coffee shops in Austin TX" --max 25 --out listings.json

# Multiple instances at once, one dashboard, all headless
python cli.py batch queries.example.txt --max 25 --concurrency 4 --outdir results/

# Enrichment (crawls sites + runs AI synthesis)
python cli.py enrich listings.json --out enriched.json

# Enrich without the AI step (just factual site crawling)
python cli.py enrich listings.json --out enriched.json --no-ai
```

`batch` reads one search query per line from a text file and runs them
concurrently, each in its own headless browser instance, all reporting
into the same terminal dashboard. `--concurrency` caps how many Chromium
processes run at once — each one is a real process with real memory/CPU
cost, so on a laptop 3-5 is usually the practical ceiling; on a beefier
machine push it higher and watch RAM.

Flags worth knowing:
- `--no-hydrate` skips clicking into each listing's detail pane — faster,
  but you only get name/rating/maps-URL, no phone/address/website.
- `--scroll-rounds N` controls how many times the results panel scrolls
  before giving up on finding more listings. Google Maps caps how many
  results it'll render per search regardless, usually ~120.
- Each worker retries its whole navigate-and-scroll sequence up to twice
  with backoff before giving up — most failures are a transient timeout,
  not a real block, and the dashboard's error panel tells you which is which.

## Things that will bite you (read before you scale this up)

- **This violates Google's Terms of Service.** Not illegal, but Google can
  and will rate-limit or block IPs that scrape Maps aggressively. This tool
  does not include CAPTCHA-solving or proxy rotation — that's a deliberate
  scope cut, not an oversight. If you need to run this at real volume,
  you'll want your own proxy pool and to space requests out generously.
- **Selectors will break.** Google changes their DOM periodically. When a
  worker finishes with 0 results, that's the tell — check the errors panel,
  it'll usually say "selector never appeared" rather than a clean timeout.
- **Concurrency ≠ free.** Each worker is a real headless Chromium process.
  Running too many at once on the same machine (and often from the same IP)
  is also the fastest way to get all of them soft-blocked simultaneously —
  stagger queries or throttle concurrency rather than maxing it out.
- **The AI enrichment step is inference, not lookup.** Claude is reading a
  homepage blurb and guessing company size/revenue the way a sharp human
  skimming the same page would. Treat `estimated_revenue_band` etc. as a
  rough sort signal, not a fact to put in a sales deck.
- **Enrichment emails may be generic** (`info@`, `hello@`) rather than a
  named contact — this tool doesn't do people-search / personal-email
  lookups, which is a different (and more privacy-sensitive) category of
  data.
- If you're using this for outreach, check CAN-SPAM / GDPR / your local
  equivalent before emailing scraped addresses at scale.

## File layout

```
cli.py                          # entry point: scrape / batch / enrich subcommands
models.py                       # RawListing, EnrichmentSignals, AIProfile, EnrichedBusiness
scraper/google_maps_scraper.py  # Playwright scraping logic, one worker's-worth
enrichment/site_crawler.py      # factual extraction: emails, phones, socials, tech
enrichment/ai_enricher.py       # Claude synthesis step
ui/console_ui.py                # MultiRunUI: the single-pane multi-worker dashboard
```

## Extending it

Natural next beasts to bolt on:
- A `dedupe.py` pass keyed on `place_id` + fuzzy name match, since the same
  business often shows up more than once across broad-radius searches.
- Swap the enrichment site crawler for a real browser (Playwright again) if
  target sites are JS-rendered SPAs — `httpx` only sees server-rendered HTML.
- Export to CSV/XLSX for handoff to a CRM — `models.EnrichedBusiness.to_dict()`
  already gives you flat-enough data to `pandas.json_normalize()` straight in.
