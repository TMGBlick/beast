"""
Single-pane dashboard for watching multiple headless scraper instances at
once. No browser rendering, no page screenshots — just cheap text state
per worker plus a shared "recent issues" feed, because the whole point is
catching the instance that silently went sideways while the other five
are fine.
"""
from rich.console import Console
from rich.table import Table
from rich.live import Live
from rich.panel import Panel
from rich.layout import Layout
from rich.text import Text
from datetime import datetime
from dataclasses import dataclass, field
import threading

console = Console()


class RunUI:
    def __init__(self, query: str, target_count: int):
        self.query = query
        self.target_count = target_count
        self.found: list[str] = []
        self.decisions: list[tuple[str, str]] = []  # (level, message)
        self.status = "starting"
        self.live: Live | None = None

    # ---- decision log -----------------------------------------------
    def decide(self, message: str, level: str = "info"):
        """Log a decision the scraper made, e.g. 'scrolling for more results'."""
        self.decisions.append((level, message))
        self.decisions = self.decisions[-12:]  # keep the panel readable
        self._refresh()

    def found_listing(self, name: str):
        self.found.append(name)
        self._refresh()

    def set_status(self, status: str):
        self.status = status
        self._refresh()

    # ---- rendering -----------------------------------------------
    def _decision_color(self, level: str) -> str:
        return {
            "info": "white",
            "action": "cyan",
            "warn": "yellow",
            "error": "red",
            "success": "green",
        }.get(level, "white")

    def _render(self) -> Panel:
        table = Table.grid(expand=True)
        table.add_column(ratio=1)
        table.add_column(ratio=1)

        # Left: decision feed
        log_text = Text()
        for level, msg in self.decisions:
            ts = datetime.now().strftime("%H:%M:%S")
            log_text.append(f"[{ts}] ", style="dim")
            log_text.append(f"{msg}\n", style=self._decision_color(level))

        # Right: running tally of found listings
        found_text = Text()
        for i, name in enumerate(self.found[-15:], 1):
            found_text.append(f"{i}. {name}\n", style="bold")

        table.add_row(
            Panel(log_text or Text("waiting..."), title="Decisions", border_style="cyan"),
            Panel(found_text or Text("none yet"), title=f"Found ({len(self.found)}/{self.target_count})", border_style="green"),
        )

        header = f"[bold]{self.query}[/bold]  —  status: [yellow]{self.status}[/yellow]"
        return Panel(table, title=header, border_style="magenta")

    def _refresh(self):
        if self.live:
            self.live.update(self._render())

    def __enter__(self):
        self.live = Live(self._render(), console=console, refresh_per_second=6)
        self.live.__enter__()
        return self

    def __exit__(self, *exc):
        self.live.__exit__(*exc)


@dataclass
class WorkerState:
    query: str
    target: int
    status: str = "queued"
    found: int = 0
    last_event: str = ""
    last_level: str = "info"
    error_count: int = 0
    warn_count: int = 0
    finished: bool = False


class MultiRunUI:
    """
    One dashboard, N workers. Each worker is one headless browser instance
    scraping one query. The table shows every worker's status at a glance;
    the panel below surfaces only the warnings/errors across all of them,
    since that's the part you actually need to watch.
    """

    LEVEL_STYLE = {
        "info": "white",
        "action": "cyan",
        "warn": "yellow",
        "error": "bold red",
        "success": "green",
    }

    def __init__(self, max_issue_rows: int = 14):
        self._lock = threading.Lock()
        self.workers: dict[str, WorkerState] = {}
        self.issues: list[tuple[str, str, str, str]] = []  # (time, worker_id, level, message)
        self.max_issue_rows = max_issue_rows
        self.live: Live | None = None

    def register(self, worker_id: str, query: str, target: int):
        with self._lock:
            self.workers[worker_id] = WorkerState(query=query, target=target)
        self._refresh()

    def update(self, worker_id: str, status: str | None = None, event: str | None = None,
               level: str = "info", found_increment: int = 0, finished: bool = False):
        with self._lock:
            w = self.workers.get(worker_id)
            if not w:
                return
            if status:
                w.status = status
            if found_increment:
                w.found += found_increment
            if finished:
                w.finished = True
                w.status = w.status or "done"
            if event:
                w.last_event = event
                w.last_level = level
                if level == "error":
                    w.error_count += 1
                elif level == "warn":
                    w.warn_count += 1
                if level in ("warn", "error"):
                    ts = datetime.now().strftime("%H:%M:%S")
                    self.issues.append((ts, worker_id, level, event))
                    self.issues = self.issues[-self.max_issue_rows:]
        self._refresh()

    def _worker_table(self) -> Table:
        table = Table(expand=True, show_lines=False)
        table.add_column("Worker", style="bold")
        table.add_column("Query")
        table.add_column("Status")
        table.add_column("Found", justify="right")
        table.add_column("Errs", justify="right")
        table.add_column("Last event")

        for wid, w in self.workers.items():
            status_style = "green" if w.finished else ("yellow" if w.status == "backing off" else "cyan")
            err_style = "bold red" if w.error_count else "dim"
            last_style = self.LEVEL_STYLE.get(w.last_level, "white")
            table.add_row(
                wid,
                w.query[:28] + ("…" if len(w.query) > 28 else ""),
                f"[{status_style}]{w.status}[/{status_style}]",
                f"{w.found}/{w.target}",
                f"[{err_style}]{w.error_count}[/{err_style}]",
                f"[{last_style}]{w.last_event[:50]}[/{last_style}]",
            )
        return table

    def _issues_panel(self) -> Panel:
        text = Text()
        if not self.issues:
            text.append("No warnings or errors yet.", style="dim")
        for ts, wid, level, msg in self.issues[-self.max_issue_rows:]:
            style = self.LEVEL_STYLE.get(level, "white")
            text.append(f"[{ts}] ", style="dim")
            text.append(f"{wid}: ", style="bold")
            text.append(f"{msg}\n", style=style)
        return Panel(text, title="Warnings & Errors (across all workers)", border_style="red")

    def _render(self):
        active = sum(1 for w in self.workers.values() if not w.finished)
        total_found = sum(w.found for w in self.workers.values())
        header = f"[bold]mapsbeast[/bold] — {active} active / {len(self.workers)} total workers, {total_found} businesses found"
        body = Table.grid(expand=True)
        body.add_row(self._worker_table())
        body.add_row(self._issues_panel())
        return Panel(body, title=header, border_style="magenta")

    def _refresh(self):
        if self.live:
            self.live.update(self._render())

    def __enter__(self):
        self.live = Live(self._render(), console=console, refresh_per_second=6)
        self.live.__enter__()
        return self

    def __exit__(self, *exc):
        self.live.__exit__(*exc)


class WorkerReporter:
    """
    Thin adapter so scraper/enrichment code can call .decide() / .found_listing()
    / .set_status() without knowing whether it's running solo or as one of N
    workers in a MultiRunUI dashboard. Every worker gets one of these.
    """

    def __init__(self, dashboard: MultiRunUI, worker_id: str):
        self.dashboard = dashboard
        self.worker_id = worker_id

    def decide(self, message: str, level: str = "info"):
        self.dashboard.update(self.worker_id, event=message, level=level)

    def found_listing(self, name: str):
        self.dashboard.update(self.worker_id, found_increment=1)

    def set_status(self, status: str):
        self.dashboard.update(self.worker_id, status=status)

    def finish(self, status: str = "done"):
        self.dashboard.update(self.worker_id, status=status, finished=True)


def print_summary_table(businesses):
    table = Table(title="Scrape + Enrichment Summary", show_lines=False)
    table.add_column("Business")
    table.add_column("Phone")
    table.add_column("Website")
    table.add_column("Email(s)")
    table.add_column("Status")

    for b in businesses:
        emails = ", ".join(b.signals.emails_found[:2]) if b.signals and b.signals.emails_found else "-"
        status_style = {
            "complete": "green", "partial": "yellow",
            "no_website": "dim", "failed": "red", "pending": "white",
        }.get(b.enrichment_status, "white")
        table.add_row(
            b.listing.name,
            b.listing.phone or "-",
            b.listing.website or "-",
            emails,
            f"[{status_style}]{b.enrichment_status}[/{status_style}]",
        )
    console.print(table)
