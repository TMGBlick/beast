"""
Core data models. Everything downstream (scraper, enrichment, output)
speaks these dataclasses so the two phases stay decoupled — you can
run Phase 1 today, sit on a JSON file, and run Phase 2 tomorrow.
"""
from dataclasses import dataclass, field, asdict
from typing import Optional
import json


@dataclass
class RawListing:
    """What we pull directly off a Google Maps result card + detail pane."""
    name: str
    category: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    website: Optional[str] = None
    rating: Optional[float] = None
    review_count: Optional[int] = None
    price_level: Optional[str] = None
    hours: Optional[str] = None
    maps_url: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    place_id: Optional[str] = None  # scraped from the URL when present, not the API's ID


@dataclass
class EnrichmentSignals:
    """Raw material scraped from the business's own website/socials.
    This is fact, not inference — every field here was observed somewhere."""
    emails_found: list = field(default_factory=list)
    phones_found: list = field(default_factory=list)
    social_profiles: dict = field(default_factory=dict)   # {"instagram": "url", ...}
    tech_signals: list = field(default_factory=list)       # e.g. ["Shopify", "Google Analytics"]
    website_title: Optional[str] = None
    website_description: Optional[str] = None
    raw_text_sample: Optional[str] = None  # trimmed homepage/about text fed to the AI step


@dataclass
class AIProfile:
    """Inference, not fact. Clearly labeled as such downstream."""
    estimated_size: Optional[str] = None
    estimated_industry: Optional[str] = None
    estimated_revenue_band: Optional[str] = None
    summary: Optional[str] = None
    confidence: Optional[str] = None  # "low" / "medium" / "high", set by the model itself


@dataclass
class EnrichedBusiness:
    listing: RawListing
    signals: Optional[EnrichmentSignals] = None
    ai_profile: Optional[AIProfile] = None
    enrichment_status: str = "pending"  # pending / no_website / partial / complete / failed

    def to_dict(self):
        return {
            "listing": asdict(self.listing),
            "signals": asdict(self.signals) if self.signals else None,
            "ai_profile": asdict(self.ai_profile) if self.ai_profile else None,
            "enrichment_status": self.enrichment_status,
        }


def save_batch(businesses: list[EnrichedBusiness], path: str):
    with open(path, "w") as f:
        json.dump([b.to_dict() for b in businesses], f, indent=2)


def load_raw_listings(path: str) -> list[RawListing]:
    with open(path) as f:
        data = json.load(f)
    return [RawListing(**d) for d in data]
