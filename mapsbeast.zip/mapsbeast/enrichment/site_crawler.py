"""
Phase 2, step 1: visit the business's own website (public pages only —
homepage + an obvious contact/about page) and pull out anything factual:
emails, phone numbers, social links, and a few tech-stack tells.

No AI here. This is pure extraction — regexes and DOM parsing — so the
output is auditable and cheap to run at scale before the expensive AI
step touches anything.
"""
import re
import httpx
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse

from models import EnrichmentSignals
from ui.console_ui import RunUI

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
PHONE_RE = re.compile(r"(\+?\d[\d\-\.\(\) ]{7,}\d)")

SOCIAL_DOMAINS = {
    "instagram.com": "instagram",
    "facebook.com": "facebook",
    "linkedin.com": "linkedin",
    "twitter.com": "twitter",
    "x.com": "twitter",
    "tiktok.com": "tiktok",
    "youtube.com": "youtube",
}

TECH_SIGNATURES = {
    "shopify": "Shopify",
    "wp-content": "WordPress",
    "cdn.shopify.com": "Shopify",
    "wixstatic.com": "Wix",
    "squarespace.com": "Squarespace",
    "webflow.com": "Webflow",
    "googletagmanager.com": "Google Tag Manager",
    "google-analytics.com": "Google Analytics",
    "hs-scripts.com": "HubSpot",
    "intercom.io": "Intercom",
}

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; MapsBeastBot/1.0; +respectful-research-crawler)"
}


def _find_socials(soup: BeautifulSoup, base_url: str) -> dict:
    socials = {}
    for a in soup.find_all("a", href=True):
        href = urljoin(base_url, a["href"])
        host = urlparse(href).netloc.replace("www.", "")
        for domain, platform in SOCIAL_DOMAINS.items():
            if domain in host and platform not in socials:
                socials[platform] = href
    return socials


def _find_tech_signals(html: str) -> list:
    found = []
    lower = html.lower()
    for sig, label in TECH_SIGNATURES.items():
        if sig in lower and label not in found:
            found.append(label)
    return found


def _find_contact_page(soup: BeautifulSoup, base_url: str) -> str | None:
    for a in soup.find_all("a", href=True):
        text = (a.get_text() or "").strip().lower()
        href = a["href"].lower()
        if "contact" in text or "contact" in href:
            return urljoin(base_url, a["href"])
    return None


def crawl_website(url: str, ui: RunUI | None = None) -> EnrichmentSignals:
    signals = EnrichmentSignals()
    if not url:
        return signals

    try:
        with httpx.Client(headers=HEADERS, timeout=10, follow_redirects=True) as client:
            resp = client.get(url)
            html = resp.text
            soup = BeautifulSoup(html, "html.parser")

            signals.website_title = soup.title.string.strip() if soup.title and soup.title.string else None
            desc_tag = soup.find("meta", attrs={"name": "description"})
            signals.website_description = desc_tag["content"].strip() if desc_tag and desc_tag.get("content") else None

            signals.emails_found = list(set(EMAIL_RE.findall(html)))[:5]
            signals.phones_found = list(set(m.strip() for m in PHONE_RE.findall(html)))[:5]
            signals.social_profiles = _find_socials(soup, url)
            signals.tech_signals = _find_tech_signals(html)

            body_text = soup.get_text(separator=" ", strip=True)
            signals.raw_text_sample = body_text[:1200]

            if ui:
                ui.decide(f"Crawled {url}: {len(signals.emails_found)} emails, "
                           f"{len(signals.social_profiles)} socials, "
                           f"{len(signals.tech_signals)} tech signals", "success")

            # If homepage had no emails, try an obvious contact page once.
            if not signals.emails_found:
                contact_url = _find_contact_page(soup, url)
                if contact_url:
                    try:
                        c_resp = client.get(contact_url)
                        more_emails = EMAIL_RE.findall(c_resp.text)
                        signals.emails_found = list(set(more_emails))[:5]
                        if ui and signals.emails_found:
                            ui.decide(f"Found {len(signals.emails_found)} email(s) on contact page", "success")
                    except Exception:
                        pass

    except Exception as e:
        if ui:
            ui.decide(f"Site crawl failed for {url}: {e}", "warn")

    return signals
