"""
Phase 2, step 2: hand the factual signals from site_crawler to Claude and
ask it to synthesize a firmographic profile.

Important framing, and this shows up in the output too: everything this
module produces is an *inference*, not a fact. The model is reading a
homepage blurb and a few tech signals and estimating company size,
industry, and revenue band the way a sharp human skimming the same page
would — educated guesses, not verified data. We ask the model to grade
its own confidence so downstream consumers can filter low-confidence
guesses out.
"""
import json
import os
from anthropic import Anthropic

from models import RawListing, EnrichmentSignals, AIProfile

client = Anthropic()  # reads ANTHROPIC_API_KEY from env

SYSTEM_PROMPT = """You estimate firmographic details about a small/local business
from limited public signals (a Google Maps listing plus scraped homepage text).
You are guessing, not looking anything up. Be conservative. If the signal is too
thin to guess responsibly, say so and mark confidence "low".

Respond ONLY with a JSON object, no markdown fences, no preamble:
{
  "estimated_size": "solo/micro (1-5) | small (6-20) | medium (21-100) | large (100+) | unknown",
  "estimated_industry": "short label, e.g. 'boutique fitness studio'",
  "estimated_revenue_band": "e.g. 'under $500k' | '$500k-$2M' | '$2M-$10M' | 'unknown'",
  "summary": "1-2 sentence plain-English summary of what this business is and who it serves",
  "confidence": "low | medium | high"
}"""


def build_user_prompt(listing: RawListing, signals: EnrichmentSignals) -> str:
    parts = [
        f"Business name: {listing.name}",
        f"Category (from Maps): {listing.category or 'unknown'}",
        f"Rating: {listing.rating} ({listing.review_count} reviews)" if listing.rating else "Rating: unknown",
        f"Address: {listing.address or 'unknown'}",
    ]
    if signals:
        if signals.website_title:
            parts.append(f"Website title: {signals.website_title}")
        if signals.website_description:
            parts.append(f"Website meta description: {signals.website_description}")
        if signals.tech_signals:
            parts.append(f"Detected website tech: {', '.join(signals.tech_signals)}")
        if signals.social_profiles:
            parts.append(f"Social platforms present: {', '.join(signals.social_profiles.keys())}")
        if signals.raw_text_sample:
            parts.append(f"Homepage text sample: {signals.raw_text_sample}")
    return "\n".join(parts)


def enrich_with_ai(listing: RawListing, signals: EnrichmentSignals) -> AIProfile:
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return AIProfile(summary="ANTHROPIC_API_KEY not set — skipped AI enrichment.", confidence="low")

    user_prompt = build_user_prompt(listing, signals)

    try:
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=400,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_prompt}],
        )
        text = response.content[0].text.strip()
        text = text.replace("```json", "").replace("```", "").strip()
        data = json.loads(text)
        return AIProfile(**data)
    except json.JSONDecodeError:
        return AIProfile(summary="AI response was not valid JSON — skipped.", confidence="low")
    except Exception as e:
        return AIProfile(summary=f"AI enrichment failed: {e}", confidence="low")
