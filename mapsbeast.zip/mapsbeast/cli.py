"""
mapsbeast — Google Maps scraper + enrichment.

Single query:
    python cli.py scrape "coffee shops in Austin TX" --max 25 --out listings.json

Multiple instances at once, one dashboard, headless the whole time:
    python cli.py batch queries.txt --max 25 --concurrency 4 --outdir results/

    # queries.txt: one search per line
    #   coffee shops in Austin TX
    #   coffee shops in Denver CO
    #   coffee shops in Portland OR

Enrichment (separate phase, run against any listings file):
    python cli.py enrich listings.json --out enriched.json
"""
import argparse
import asyncio
import json
import os
import re

from models import RawListing, EnrichedBusiness, save_batch, load_raw_listings
from scraper.google_maps_scraper import scrape_google_maps
from enrichment.site_crawler import crawl_website
from enrichment.ai_enricher import enrich_with_ai
from ui.console_ui import console, print_summary_table, MultiRunUI, WorkerReporter


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:60]


# ---------------------------------------------------------------- scrape (single)
def cmd_scrape(args):
    dashboard = MultiRunUI()
    worker_id = "w1"
    dashboard.register(worker_id, args.query, args.max)
    reporter = WorkerReporter(dashboard, worker_id)

    with dashboard:
        listings = asyncio.run(
            scrape_google_maps(
                query=args.query,
                ui=reporter,
                max_results=args.max,
                hydrate_details=not args.no_hydrate,
                scroll_rounds=args.scroll_rounds,
            )
        )

    with open(args.out, "w") as f:
        json.dump([l.__dict__ for l in listings], f, indent=2)
    console.print(f"[green]Saved {len(listings)} listings to {args.out}[/green]")


# ---------------------------------------------------------------- scrape (batch)
async def _run_batch(queries, args, dashboard):
    semaphore = asyncio.Semaphore(args.concurrency)
    os.makedirs(args.outdir, exist_ok=True)

    async def run_one(i, query):
        worker_id = f"w{i+1}"
        dashboard.register(worker_id, query, args.max)
        reporter = WorkerReporter(dashboard, worker_id)
        async with semaphore:
            listings = await scrape_google_maps(
                query=query,
                ui=reporter,
                max_results=args.max,
                hydrate_details=not args.no_hydrate,
                scroll_rounds=args.scroll_rounds,
            )
        out_path = os.path.join(args.outdir, f"{_slug(query)}.json")
        with open(out_path, "w") as f:
            json.dump([l.__dict__ for l in listings], f, indent=2)
        return query, out_path, len(listings)

    return await asyncio.gather(*(run_one(i, q) for i, q in enumerate(queries)))


def cmd_batch(args):
    with open(args.queries_file) as f:
        queries = [line.strip() for line in f if line.strip()]

    if not queries:
        console.print("[red]No queries found in file.[/red]")
        return

    console.print(
        f"[bold magenta]Batch scrape:[/bold magenta] {len(queries)} queries, "
        f"max {args.concurrency} concurrent headless instance(s)"
    )

    dashboard = MultiRunUI()
    with dashboard:
        results = asyncio.run(_run_batch(queries, args, dashboard))

    console.print("\n[bold]Batch complete:[/bold]")
    for query, path, count in results:
        console.print(f"  {query!r} -> {count} listings -> {path}")


# ---------------------------------------------------------------- enrich
def cmd_enrich(args):
    listings = load_raw_listings(args.input)
    console.print(f"[bold magenta]Enriching:[/bold magenta] {len(listings)} businesses")

    dashboard = MultiRunUI()
    worker_id = "enrich"
    dashboard.register(worker_id, f"{len(listings)} businesses", len(listings))
    reporter = WorkerReporter(dashboard, worker_id)

    businesses = []
    with dashboard:
        for listing in listings:
            eb = EnrichedBusiness(listing=listing)

            if not listing.website:
                eb.enrichment_status = "no_website"
                reporter.decide(f"{listing.name}: no website, skipping", "warn")
                businesses.append(eb)
                reporter.found_listing(listing.name)
                continue

            reporter.decide(f"{listing.name}: crawling site", "action")
            eb.signals = crawl_website(listing.website)

            if args.ai:
                reporter.decide(f"{listing.name}: AI profile synthesis", "action")
                eb.ai_profile = enrich_with_ai(listing, eb.signals)

            eb.enrichment_status = "complete" if eb.signals.emails_found else "partial"
            businesses.append(eb)
            reporter.found_listing(listing.name)
        reporter.finish("done")

    save_batch(businesses, args.out)
    console.print(f"[green]Saved enriched data to {args.out}[/green]")
    print_summary_table(businesses)


def main():
    parser = argparse.ArgumentParser(description="mapsbeast: scrape + enrich Google Maps businesses")
    sub = parser.add_subparsers(dest="command", required=True)

    p_scrape = sub.add_parser("scrape", help="scrape a single query")
    p_scrape.add_argument("query")
    p_scrape.add_argument("--max", type=int, default=30)
    p_scrape.add_argument("--out", default="listings.json")
    p_scrape.add_argument("--no-hydrate", action="store_true")
    p_scrape.add_argument("--scroll-rounds", type=int, default=6)
    p_scrape.set_defaults(func=cmd_scrape)

    p_batch = sub.add_parser("batch", help="run N queries concurrently under one dashboard")
    p_batch.add_argument("queries_file", help="text file, one search query per line")
    p_batch.add_argument("--max", type=int, default=30)
    p_batch.add_argument("--concurrency", type=int, default=3, help="max simultaneous headless browser instances")
    p_batch.add_argument("--outdir", default="results")
    p_batch.add_argument("--no-hydrate", action="store_true")
    p_batch.add_argument("--scroll-rounds", type=int, default=6)
    p_batch.set_defaults(func=cmd_batch)

    p_enrich = sub.add_parser("enrich", help="enrich a scraped listings file")
    p_enrich.add_argument("input")
    p_enrich.add_argument("--out", default="enriched.json")
    p_enrich.add_argument("--ai", action="store_true", default=True)
    p_enrich.add_argument("--no-ai", dest="ai", action="store_false")
    p_enrich.set_defaults(func=cmd_enrich)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
