"""
Direct-scraping engine for Google Maps search results.

Honest flags before you run this:
  - This violates Google's Terms of Service. It's not illegal, but your
    IP/account can get rate-limited or blocked, and Google's DOM changes
    without notice, which breaks selectors. Budget for maintenance.
  - Headless Chromium is more detectable than a real browser. This module
    does basic hardening (real UA, viewport, slight randomized delays) but
    is not an anti-detection suite — that's a separate, deeper rabbit hole
    and not something built into this tool.
  - Respect rate limits you set yourself. Hammering Maps fast is the
    quickest way to get blocked and the least polite way to use someone
    else's infrastructure.
"""
import asyncio
import random
import re
from playwright.async_api import async_playwright, Page

from models import RawListing

SEARCH_URL = "https://www.google.com/maps/search/{query}"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)


async def _human_delay(a=0.4, b=1.3):
    await asyncio.sleep(random.uniform(a, b))


def _extract_place_id(url: str) -> str | None:
    match = re.search(r"!1s(0x[0-9a-fA-F:]+)", url)
    return match.group(1) if match else None


def _extract_lat_lng(url: str) -> tuple[float | None, float | None]:
    match = re.search(r"@(-?\d+\.\d+),(-?\d+\.\d+)", url)
    if match:
        return float(match.group(1)), float(match.group(2))
    return None, None


async def _scroll_results_panel(page: Page, ui, rounds: int):
    """Google Maps lazy-loads results as you scroll the left-hand panel."""
    panel_selector = 'div[role="feed"]'
    try:
        await page.wait_for_selector(panel_selector, timeout=8000)
    except Exception:
        ui.decide("Results panel never appeared — page layout may have changed.", "error")
        return

    for i in range(rounds):
        ui.decide(f"Scrolling results panel (pass {i+1}/{rounds})", "action")
        await page.eval_on_selector(
            panel_selector, "el => el.scrollBy(0, el.scrollHeight)"
        )
        await _human_delay(0.8, 1.6)


async def _extract_card_data(card, ui) -> RawListing | None:
    try:
        name_el = await card.query_selector('div.qBF1Pd, div[class*="fontHeadlineSmall"]')
        name = (await name_el.inner_text()).strip() if name_el else None
        if not name:
            return None

        href_el = await card.query_selector("a")
        maps_url = await href_el.get_attribute("href") if href_el else None

        text_blob = await card.inner_text()
        rating_match = re.search(r"(\d\.\d)\s?\(", text_blob)
        review_match = re.search(r"\((\d[\d,]*)\)", text_blob)
        rating = float(rating_match.group(1)) if rating_match else None
        review_count = int(review_match.group(1).replace(",", "")) if review_match else None

        lat, lng = _extract_lat_lng(maps_url or "")
        place_id = _extract_place_id(maps_url or "")

        return RawListing(
            name=name,
            maps_url=maps_url,
            rating=rating,
            review_count=review_count,
            latitude=lat,
            longitude=lng,
            place_id=place_id,
        )
    except Exception as e:
        ui.decide(f"Failed to parse a card: {e}", "warn")
        return None


async def _hydrate_detail_pane(page: Page, listing: RawListing, ui):
    """Click into a listing to grab phone/address/website/hours that only
    render in the detail pane, not the search card."""
    try:
        await page.click(f'text="{listing.name}"', timeout=5000)
        await _human_delay(0.6, 1.2)

        async def safe_text(selector):
            el = await page.query_selector(selector)
            return (await el.inner_text()).strip() if el else None

        listing.address = await safe_text('button[data-item-id="address"]')
        listing.phone = await safe_text('button[data-item-id^="phone"]')
        website_el = await page.query_selector('a[data-item-id="authority"]')
        listing.website = await website_el.get_attribute("href") if website_el else None
        listing.category = await safe_text('button[jsaction*="category"]')

        ui.decide(f"Hydrated detail pane for '{listing.name}'", "success")
    except Exception as e:
        ui.decide(f"Could not hydrate '{listing.name}': {e}", "warn")


async def scrape_google_maps(
    query: str,
    ui,
    max_results: int = 30,
    hydrate_details: bool = True,
    scroll_rounds: int = 6,
    max_retries: int = 2,
) -> list[RawListing]:
    """
    Entry point for ONE worker. Always headless — no window is ever rendered,
    that's the whole point when you're running several of these at once.
    `ui` is a WorkerReporter (or anything with .decide/.found_listing/.set_status)
    already bound to this worker's row in the shared dashboard.

    Retries the whole navigate-and-scroll sequence up to `max_retries` times
    on hard failures (timeout, crashed page, selector never appearing) since
    that's the most common way these silently die — a transient Google
    hiccup or a slow network, not a real block.
    """
    attempt = 0
    while attempt <= max_retries:
        attempt += 1
        results: list[RawListing] = []
        try:
            ui.set_status(f"launching (attempt {attempt})")
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context(
                    user_agent=USER_AGENT,
                    viewport={"width": 1366, "height": 900},
                )
                page = await context.new_page()

                url = SEARCH_URL.format(query=query.replace(" ", "+"))
                ui.decide(f"Navigating to search results", "action")
                ui.set_status("loading")
                await page.goto(url, timeout=30000)
                await _human_delay(1.5, 2.5)

                await _scroll_results_panel(page, ui, rounds=scroll_rounds)

                ui.set_status("extracting")
                cards = await page.query_selector_all('div[role="feed"] > div > div[jsaction]')
                ui.decide(f"Found {len(cards)} candidate cards", "info")

                for card in cards:
                    if len(results) >= max_results:
                        break
                    listing = await _extract_card_data(card, ui)
                    if listing:
                        results.append(listing)
                        ui.found_listing(listing.name)

                if hydrate_details:
                    ui.set_status("hydrating details")
                    for listing in results:
                        await _hydrate_detail_pane(page, listing, ui)
                        await _human_delay(0.5, 1.0)

                await browser.close()

            if not results:
                ui.decide("Zero results extracted — likely a selector break or a soft block.", "warn")
            ui.finish("done")
            return results

        except Exception as e:
            ui.decide(f"Attempt {attempt} crashed: {e}", "error")
            if attempt > max_retries:
                ui.finish("failed")
                return results
            backoff = 3 * attempt
            ui.set_status(f"backing off {backoff}s")
            await asyncio.sleep(backoff)

    ui.finish("failed")
    return results
